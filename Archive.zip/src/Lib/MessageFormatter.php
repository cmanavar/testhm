<?php

class MessageFormatter
{
    public static function formatMessage($locale, $pattern, array $args)
    {
    }
}