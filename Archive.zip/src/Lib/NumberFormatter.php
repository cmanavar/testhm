<?php

class NumberFormatter
{
    const DECIMAL             = 1;
    const MIN_FRACTION_DIGITS = 23;
    const MAX_FRACTION_DIGITS = 22;

    public function setAttribute($attr, $value)
    {
    }

    public function format($value, $type = null)
    {
    }
}
